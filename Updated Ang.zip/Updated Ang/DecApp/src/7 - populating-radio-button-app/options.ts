export class Options {
  constructor(public id: number, public name: string, public price: number) { }
}