import { Options } from './options';

import {Component, NgModule} from '@angular/core'
;
import {BrowserModule} from '@angular/platform-browser';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})


export class AppComponent {
totalPrice: number = 0;
selectedOption:Options = new Options(2, 'T-Shirts', 200);
  

options = [
     new Options(1, 'Jeans', 700 ),
     new Options(2, 'T-Shirts', 450),
     new Options(3, 'Shorts', 350 ),
     new Options(4, 'Shirts', 600)
,     new Options(5, 'Trousers', 400 ),
     new Options(6, 'Chinos', 400),
     new Options(7, 'Shoes', 700)
  ];
  
  

// getValue(optionid: any) 
// {
      
// this.selectedOption = this.options.filter((item)=> item.id == optionid)[0];
  
// }

public getValue( event: any,id: any) 
{
  console.log(event);
  this.selectedOption = this.options.filter((item)=> item.id == id)[0];
  this.options.forEach((option)=> {
  
  if(event.target.checked) {
    this.totalPrice += this.selectedOption.price;
  } else {
    this.totalPrice -= this.selectedOption.price;
  }
});
  
}


}