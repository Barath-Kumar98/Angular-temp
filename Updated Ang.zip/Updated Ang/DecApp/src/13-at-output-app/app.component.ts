import { Component } from '@angular/core';
 
@Component({
  selector: 'app-root',
  styles: [`
    .app {
      display: block;
      text-align: center;
      padding: 25px;
      background: #f5f5f5;
    }
  `],
  template: `
    <div class="app">
      Parent: {{ total }}
      <div *ngFor="let val of myCount">
      <counter
        [count]="val"
        (change)="countChange($event)">
      </counter>
 
      </div>
    </div>
  `
})
export class AppComponent {
  total: number = 0;
  myCount: number[] = [10,8,6,11,9];
  constructor(){
    for(let val of this.myCount){
      this.total += val;
    }
  }
  countChange(event: any) {
    //this.myCount = event;
    this.total += event;
  }
}