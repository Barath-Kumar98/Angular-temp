import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pfunction'
})
export class PfunctionPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
