import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `<h2>About(updated)</h2>`
})
export class AboutComponent { }