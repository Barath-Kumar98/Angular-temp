import { Component, OnInit} from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app.component.html'
})
export class AppComponent implements OnInit{
	myMsg = 'Stock price increasing';

	  constructor() {
		setTimeout(()=>{this.myMsg = "Stockprice Decreasing";}, 10000)
	  }
  ngOnInit(): void {
  }


}