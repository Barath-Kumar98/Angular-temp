import { Buyer } from "./buyer";
import { Product } from "./product";

// export interface Cart {
//     id: number,
//     product: Product,
//     purchaseQuantity: number,
//     buyer: Buyer,
//     purchaseStatus: boolean
// }


export interface Cart {
    id: number,
    product_id: number,
    quantity: number,
    buyer_id: number,
    purchaseStatus: boolean,
    purchaseDate: Date
}


export interface CartDTO {
    id: number,
    product: Product,
    quantity: number,
    buyer: Buyer,
    purchaseStatus: boolean,
    purchaseDate: Date
}