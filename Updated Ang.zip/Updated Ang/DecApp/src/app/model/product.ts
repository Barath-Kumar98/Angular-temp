export interface Product {
    pid: number,
    productname: string,
    productModel: string,
    brandName: string,
    category: string,
    subCategory: string,
    productPrice: number,
    quantity: number,
    image: string,
    productSpecs: string,
    sellerId: number,
    status: string
}


export interface ProductDTO {
    product: Product,
    quantity: number,
    isSelected: boolean,
    cartId: number
}