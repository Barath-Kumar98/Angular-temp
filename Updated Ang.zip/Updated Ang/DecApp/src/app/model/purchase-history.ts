import { Buyer } from "./buyer";
import { Cart } from "./cart";

export interface PurchaseHistory {
    id: number,
    cart: Cart,
    purchaseQuantity: number,
    buyer: Buyer,
    purchaseDate: Date
}




