import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';
import { Cart, CartDTO } from '../model/cart';
import { Product } from '../model/product';
import { PurchaseHistory } from '../model/purchase-history';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-purchase-history',
  templateUrl: './purchase-history.component.html',
  styleUrls: ['./purchase-history.component.css']
})
export class PurchaseHistoryComponent implements OnInit {

  cartList: Cart[] =[];
  cartDTOList: CartDTO[] =[];
  productList: Product[] = [];

  purchaseList: PurchaseHistory[] = [];
  purchaseEmpty: boolean = true;
  constructor(private productService: ProductService, private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.getAllProducts();
    
  }


  getAllProducts(){

    this.productService.getAllProducts().subscribe((response: any)=>{
      console.log(response);
      this.productList = response;
      this.getCartList();

     
    });
  }

  getCartList() {
    this.productService.getCartList().subscribe((response: any)=>{
      this.cartList = response.filter((cart: Cart)=> !cart.purchaseStatus);
      this.cartList.forEach(cart => {
        let cartDTO: CartDTO = {
          id: cart.id,
          product: this.productList.filter(product => cart.product_id === product.pid)[0],
          quantity: cart.quantity,
          buyer: this.authenticationService.getBuyer(),
          purchaseStatus: false,
          purchaseDate: new Date()
        };
        this.cartDTOList.push(cartDTO);
      })
      console.log(this.cartList);
      if(this.cartList != null && this.cartList.length !=0){
        this.purchaseEmpty = false;
      }else{
        this.purchaseEmpty = true;
      }
    });
  }

  // getPurchaseList() {
  //   this.productService.getPurchaseList().subscribe((response: any)=>{
  //     this.purchaseList = response.filter((cart: Cart)=> cart.purchaseStatus);
  //     console.log(this.purchaseList);
  //     if(this.purchaseList != null && this.purchaseList.length !=0){
  //       this.purchaseEmpty = false;
  //     }else{
  //       this.purchaseEmpty = true;
  //     }
  //   });
  // }

  getTotalAmount(cartDTO: CartDTO) {
    return (cartDTO.product.productPrice * cartDTO.quantity);
  }

  
  

}
