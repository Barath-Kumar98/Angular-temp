var s = "{\"name\":\"abc\", \"age\":24, \"salary\":20000}";
var e = JSON.parse(s);
console.log(e);