import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Buyer } from './model/buyer';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  token: string = "";
  userID: string = "";
  isLoggedIn: boolean = false;
  // authenticationApiUrl = "http://localhost:8083/authentication-service/authentication";
  buyer!: Buyer;
  constructor(private httpClient: HttpClient) { }

  getBuyer() {
    return this.buyer;
  }

  authenticate(userID: string, password: string): Observable<any> {

    // let obs = new Observable((observer) => {
    //   observer.next("token");
    // });
    // return obs;

    let tempBuyer: Buyer = {
      id: 0,
      buyerName: "",
      password: password,
      email: userID
    }

    return this.httpClient.post<any>("http://localhost:9091/buyerMicro/user/login", tempBuyer);
  }

  register(user: Buyer){
    
    return this.httpClient.post<any>("http://localhost:9091/buyerMicro/createbuyer", user);

    // let obs = new Observable((observer) => {
    //   observer.next(user);
    // });
    // return obs;
  }


  getToken(){
    return this.token;
  }

  setToken(token: string){
    this.token = token;
  }

  getUserID(){
    return this.userID;
  }

  setUserID(userID: string){
    this.userID = userID;
  } 

  getIsLoggedIn(){
    return this.isLoggedIn;
  }

  setIsLoggedIn(isLoggedIn: boolean){
    this.isLoggedIn = isLoggedIn;
  }
}