import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { Cart } from '../model/cart';
import { Product, ProductDTO } from '../model/product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-get-products',
  templateUrl: './get-products.component.html',
  styleUrls: ['./get-products.component.css']
})
export class GetProductsComponent implements OnInit {
  

    productList: Product[] = [];
    productDTOList: ProductDTO[] = [];
    // newProductList: Product[] = [];
    // offerList: any;
    sideBarSwitch!: boolean;
    firstName: string = "";
    searchString: string = "";
    dataLoaded!: Promise<boolean>;
    constructor(private productService: ProductService, private authenticationService: AuthenticationService, private router: Router) { }
  
    ngOnInit() {
      this.firstName = this.authenticationService.getUserID();
      this.sideBarSwitch = false;
      this.getAllProducts();
  
      
      var dropdown = document.getElementsByClassName("dropdown-btn");
      var i;
  
      for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function(this: any) {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
        } else {
        dropdownContent.style.display = "block";
        }
        });
      }
    }
  
    getAllProducts(){

      this.productService.getAllProducts().subscribe((response: any)=>{
        console.log(response);
        this.productList = response;

        this.convertToDto();

        // this.productService.getCurrentDateOffers().subscribe((response)=>{
        //   this.offerList = response;
        // });
        this.dataLoaded = Promise.resolve(true);
      });
    }

    convertToDto() {
      this.productDTOList = [];
        this.productList.forEach(product => {
          let productDto : ProductDTO = {
            product : product,
            quantity: 0,
            isSelected: false,
            cartId: 0
          }
          this.productDTOList.push(productDto);
        });
    }

    addToCart(productDTO: ProductDTO) {

      let cart: Cart = {
        id: 0,
        product_id: productDTO.product.pid,
        quantity: productDTO.quantity,
        buyer_id: 0,
        purchaseStatus: false,
        purchaseDate: new Date()
      }

      
      this.productService.addToCart(cart).subscribe((response: any)=>{
        let cart: Cart = response;
        this.productDTOList.forEach(dto=>{
          if(dto.product.pid === productDTO.product.pid)
           {
             dto.isSelected = true;
             dto.cartId = cart.id;
           }
        });
      });

      

      //Add to cart logic
  }
  
  removeFromCart(productDTO: ProductDTO) {
      // let index = this.getProductIndex(productOrder.product);
      // if (index > -1) {
      //     this.shoppingCartOrders.productOrders.splice(
      //         this.getProductIndex(productOrder.product), 1);
      // }
      // this.ecommerceService.ProductOrders = this.shoppingCartOrders;
      // this.shoppingCartOrders = this.ecommerceService.ProductOrders;
      // this.productSelected = false;


      // remove from cart logic


      this.productService.removeFromCart(productDTO.cartId).subscribe((response: any)=>{
        this.productDTOList.forEach(dto=>{
          if(dto.product.pid === productDTO.product.pid)
           {
             dto.isSelected = false;
             dto.cartId = 0;
           }
        });
      });

      
  }
  

  
  
  
    callNav() {
      if(this.sideBarSwitch == false){
        document.getElementById("mySidebar")!.style.width = "250px";
        document.getElementById("main")!.style.marginLeft = "250px";
        this.sideBarSwitch = true;
      }else{
        document.getElementById("mySidebar")!.style.width = "0";
        document.getElementById("main")!.style.marginLeft= "0";
        this.sideBarSwitch = false;  
      }
      
    }
    
    closeNav() {
      document.getElementById("mySidebar")!.style.width = "0";
      document.getElementById("main")!.style.marginLeft= "0";
      this.sideBarSwitch = false;  
    }
  
    filterData(){
      let filter = this.searchString.toLocaleLowerCase();
      
      // this.productList = this.productService.getAllProducts();
      this.productService.getAllProducts().subscribe((response: any)=>{
        this.productList = response.filter(
          (product: any) => product.productName.toLocaleLowerCase().indexOf(filter) != -1
        );
        if(this.productList.length == 0){
          this.productList = response.filter(
            (product: any) => product.category.toLocaleLowerCase().indexOf(filter) != -1
          );
        }

        if(this.productList.length == 0){
          this.productList = response.filter(
            (product: any) => product.subCategory.toLocaleLowerCase().indexOf(filter) != -1
          );
        }
        this.convertToDto();
      });
    }
  
  
 
    
  



  
  }
  


