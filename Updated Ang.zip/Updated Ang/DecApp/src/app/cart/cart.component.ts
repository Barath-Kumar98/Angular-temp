import { Component, OnInit } from '@angular/core';
// import { threadId } from 'worker_threads';
import { AuthenticationService } from '../authentication.service';
import { Cart, CartDTO } from '../model/cart';
import { Product } from '../model/product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartList: Cart[] =[];
  cartDTOList: CartDTO[] =[];
  cartEmpty: boolean = true;
  productList: Product[] = [];
  constructor(private productService: ProductService, private authenticationService: AuthenticationService) { }

  ngOnInit() {

    this.getAllProducts();
    
  }

  getAllProducts(){

    this.productService.getAllProducts().subscribe((response: any)=>{
      console.log(response);
      this.productList = response;
      this.getCartList();

     
    });
  }

  getCartList() {
    this.productService.getCartList().subscribe((response: any)=>{
      console.log(response)
      this.cartList = response.filter((cart: Cart)=> !cart.purchaseStatus);
      this.cartList.forEach(cart => {
        let cartDTO: CartDTO = {
          id: cart.id,
          product: this.productList.filter(product => cart.product_id === product.pid)[0],
          quantity: cart.quantity,
          buyer: this.authenticationService.getBuyer(),
          purchaseStatus: false,
          purchaseDate: new Date()
        };
        this.cartDTOList.push(cartDTO);
      })
      console.log(this.cartList);
      if(this.cartList != null && this.cartList.length !=0){
        this.cartEmpty = false;
      }else{
        this.cartEmpty = true;
      }
    });
  }

  getTotalAmount(cartDTO: CartDTO) {
    return (cartDTO.product.productPrice * cartDTO.quantity);
  }

  checkout(cartDTO: CartDTO) {
    
    let cart: Cart = this.cartList.filter(c => c.id === cartDTO.id)[0];

    cart.purchaseStatus = true;
    cart.purchaseDate = new Date;
    
    //update cart

    // add to purchaseHistory
    this.productService.checkout(cart).subscribe((response: any)=>{
      alert("Order Placed Successfully");
      this.getAllProducts();
    });

    
  }
  

}
