package com.training.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Ticket {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String fromPlace;
	private String toPlace;
	private String trvls;
	
	public Ticket() {
		// TODO Auto-generated constructor stub
	}
	public Ticket(int id, String fromPlace, String toPlace, String trvls) {
		super();
		this.id = id;
		this.fromPlace = fromPlace;
		this.toPlace = toPlace;
		this.trvls = trvls;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public String getTrvls() {
		return trvls;
	}
	public void setTrvls(String trvls) {
		this.trvls = trvls;
	}
	@Override
	public String toString() {
		return "Ticket [id=" + id + ", fromPlace=" + fromPlace + ", toPlace=" + toPlace + ", trvls=" + trvls + "]";
	}
	
	
	
}
