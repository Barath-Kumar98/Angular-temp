package com.training.model;

public class AuthToken {

    private String token;
    private String buyerName;


	public String getbuyerName() {
		return buyerName;
	}

	public void setbuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public AuthToken(){

    }

    public AuthToken(String token, String username){
        this.token = token;
        this.buyerName = buyerName;
    }

    public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

}
