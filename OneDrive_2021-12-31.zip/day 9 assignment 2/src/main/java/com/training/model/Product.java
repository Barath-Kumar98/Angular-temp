package com.training.model;


import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.catalina.startup.Catalina;

@Entity
@Table(name = "Product")
public class Product implements Comparator<Product>{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pid;

	@Column(name = "productname")
	private String productname;

	@Column(name = "price")
	private int price;

	@Column(name = "status")
	private boolean status;



//	@ManyToOne
//	@JoinColumn(name = "id")
//	private Category category;

//	public Product(int pid, String name, int price, boolean status) {
//		super();
//		this.pid = pid;
//		this.name = name;
//		this.price = price;
//		this.status = status;
//	
//		//this.category = category;
//	}

//	public Category getCategory() {
//		return category;
//	}

//	public void setCategory(Category category) {
//		this.category = category;
//	}
//
//	public Seller getSeller() {
//		return seller;
//	}
//
//	public void setSeller(Seller seller) {
//		this.seller = seller;
//	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getName() {
		return productname;
	}

	public void setName(String name) {
		this.productname = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Product(int pid, String name, int price, boolean status) {
		super();
		this.pid = pid;
		this.productname = name;
		this.price = price;
		this.status = status;

	}

	public Product() {
		super();
	}

	public Product(String name, int price, boolean status) {
		this.productname = name;
		this.price = price;
		this.status = status;
//		this.seller = seller;
//		this.category = category;
	}

	@Override
	public String toString() {
		return "\n Product [pid=" + pid + ", name=" + productname + ", price=" + price + ", status=" + status + "]";
	}

	@Override
	public int compare(Product arg0, Product arg1) {
		return arg0.price - arg1.price;
	}

}
