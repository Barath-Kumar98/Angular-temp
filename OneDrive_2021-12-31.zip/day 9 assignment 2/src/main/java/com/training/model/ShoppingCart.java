package com.training.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Entity
@Table(name="Cart")
@Component
public class ShoppingCart {
		
//	//OneToOne
//   @Autowired
//	Product product;

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="product_id")
	private int product_id;
	
	@Column(name="buyer_id")
	private int buyer_id;

	public ShoppingCart(int id, int quantity, int product_id, int buyer_id) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.product_id = product_id;
		this.buyer_id = buyer_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}



	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public int getBuyer_id() {
		return buyer_id;
	}

	public void setBuyer_id(int buyer_id) {
		this.buyer_id = buyer_id;
	}

	@Override
	public String toString() {
		return "ShoppingCart [id=" + id + ", quantity=" + quantity + ", product_id=" + product_id + ", buyer_id=" + buyer_id + "]";
	}

	public ShoppingCart() {
	}
	

}
