/**
 * 
 */
package com.training.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.training.model.Buyer;
import com.training.model.ShoppingCart;
import com.training.repository.BuyerRepository;
import com.training.service.BuyerService;
import com.training.service.ShoppingCartService;

import exception.RecordNotFoundException;

@RestController
@RequestMapping("/buyerMicro")
public class BuyerMicroController {

	@Autowired
	BuyerService service;

	@Autowired
	BuyerRepository repository;

	@Autowired
	ShoppingCartService shopService;

	@GetMapping("/hello")
	public String sayHello() {
		return "Hello Anuja";
	}

	@PostMapping("/createbuyer")
	public ResponseEntity<Buyer> createBuyer(@RequestBody Buyer buyer) throws RecordNotFoundException {
		Buyer updated = service.createBuyer(buyer);
		return new ResponseEntity<Buyer>(updated, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/addToCart")
	public ShoppingCart addToCart(@RequestBody ShoppingCart cart) {
		return shopService.addToCart(cart);

	}

	// This method will return Product Id of the product which has been deleted.
	@DeleteMapping("/DeleteFromCart/{productid}")
	public Integer DeleteFromCart(@PathVariable(name = "productid") int pid) {
		return shopService.deleteProductsFromCart(pid);
	}

	// update the price of product by seller
	@PutMapping("/updateCart")
	public ShoppingCart updateCart(@RequestBody ShoppingCart product) {
		return shopService.updateCart(product);
	}

	@GetMapping("/getAllCarts/{buyerid}")
	public List<ShoppingCart> getSellerProduct(@PathVariable(name = "buyerid") Integer buyerid) {
		return service.showCart(buyerid);
	}
}
