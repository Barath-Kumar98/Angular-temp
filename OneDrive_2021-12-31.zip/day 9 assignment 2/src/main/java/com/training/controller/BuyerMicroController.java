/**
 * 
 */
package com.training.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.training.model.Buyer;
import com.training.model.ShoppingCart;
import com.training.repository.BuyerRepository;
import com.training.service.BuyerService;
import com.training.service.ShoppingCartService;

import exception.RecordNotFoundException;


@RestController
@RequestMapping("/buyerMicro")
public class BuyerMicroController {

	@Autowired
	BuyerService service;

	@Autowired
	BuyerRepository repository;

	@Autowired
	ShoppingCartService shopService;

	@GetMapping("/hello")
	public String sayHello() {
		return "Hello Samriddhi";
	}

	@GetMapping("/getproductsforseller")
	public String getAllProducts() {

		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "http://localhost:8989/mentorportal/sellerService/sellerTech/getSellerProduct";
		URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);

		// Verify request succeed
		System.out.println("Status code: " + result.getStatusCodeValue());
		System.out.println("result: " + result.getBody());

		return "Status code: " + result.getStatusCodeValue() + "<br>result: " + result.getBody();
	}

	@GetMapping("/getproductsBasedOnName/{productname}")
	public String getProductsFromCategory(@PathVariable(name = "productname") String pname) {

		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "http://localhost:8989/mentorportal/sellerService/sellerTech/searchproductname/" + pname;
		URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);

		// Verify request succeed
		System.out.println("Status code: " + result.getStatusCodeValue());
		System.out.println("result: " + result.getBody());

		return "Status code: " + result.getStatusCodeValue() + "<br>result: " + result.getBody();
	}

	@GetMapping("/getproductsBasedOnCategory/{name}")
	public String getsearchedproduct(@PathVariable(name = "name") String categoryName) {
		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "http://localhost:8989/mentorportal/sellerService/sellerTech/searchproduct/"
				+ categoryName;
		URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);

		// Verify request succeed
		System.out.println("Status code: " + result.getStatusCodeValue());
		System.out.println("result: " + result.getBody());

		return "Status code: " + result.getStatusCodeValue() + "<br>result: " + result.getBody();

	}

	@PostMapping("/createbuyer")
	public ResponseEntity<Buyer> createBuyer( @RequestBody Buyer buyer)
			throws RecordNotFoundException {
		Buyer updated = service.createBuyer(buyer);
		return new ResponseEntity<Buyer>(updated, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping("/addToCart")
	public ShoppingCart addToCart(@RequestBody ShoppingCart cart) {
		return shopService.addToCart(cart);

	}
	
//	// This method will return Product Id of the product which has been deleted.
//	@DeleteMapping("/DeleteFromCart/{buyerid}/{productid}")
//	public Integer DeleteFromCart(@PathVariable(name = "buyerid") int bid, @PathVariable(name = "productid") int pid) {
//
//		return shopService.deleteProductsFromCart(bid, pid);
//
//	}
	
	// This method will return Product Id of the product which has been deleted.
		@DeleteMapping("/DeleteFromCart/{productid}")
		public Integer DeleteFromCart(@PathVariable(name = "productid") int pid) {
			return shopService.deleteProductsFromCart(pid);
		}
		
		// update the price of product by seller
		@PutMapping("/updateCart")
		public ShoppingCart updateCart(@RequestBody ShoppingCart product) {
			return shopService.updateCart(product);
		}
	
	@GetMapping("/show/{buyerid}")
	public String showCart(@PathVariable(name = "buyerid") int byuerId) throws Exception {
		List<Integer> pList = shopService.showCart(byuerId);

		RestTemplate restTemplate = new RestTemplate();

		final String baseUrl = "http://localhost:8989/mentorportal/sellerService/sellerTech/get";
		URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		ResponseEntity<String> result = restTemplate.postForEntity(uri, pList, String.class);

		// Verify request succeed
		System.out.println("Status code: " + result.getStatusCodeValue());
		System.out.println("result: " + result.getBody().substring(1, result.getBody().length() - 1));

		// JSONObject object = new JSONObject(result.getBody().substring(1,
		// result.getBody().length()-1));

		return result.getBody();

	}

	
//	@PostMapping("/get")
//	public List<ShoppingCart> getItemsInCart(@RequestBody List<Integer>list) {
//		return service.getProducts(list);
//	}
}
