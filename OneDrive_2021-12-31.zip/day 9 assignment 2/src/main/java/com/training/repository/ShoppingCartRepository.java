package com.training.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.training.model.ShoppingCart;


@Repository
public interface ShoppingCartRepository extends JpaRepository<com.training.model.ShoppingCart, Integer> {

	@Query(value="select * from cart c where c.buyerid=?1", nativeQuery=true)
	public List<ShoppingCart> showCart(int byuerId) ;

	
	@Modifying
    @Transactional
	@Query(value="Delete from cart c where c.id=?1", nativeQuery=true)
	public Integer deleteProductFromCart(int id);
}
