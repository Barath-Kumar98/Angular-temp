package com.training.repository;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.training.model.Buyer;


 
@Repository
public interface BuyerRepository
        extends PagingAndSortingRepository<Buyer, Long>  {

	
	//List<Product> findByProductName(String productname);

 
}