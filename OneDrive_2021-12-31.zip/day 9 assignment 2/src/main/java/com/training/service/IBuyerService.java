package com.training.service;

import java.util.List;

import com.training.model.Buyer;
import com.training.model.ShoppingCart;


public interface IBuyerService {
	
	 Buyer save(Buyer user);
	    List<Buyer> findAll();
	    void delete(int id);

	    Buyer findOne(String username);

	    Buyer findById(int id);
		List<ShoppingCart> showCart(int buyerid);

}
