package com.training.service;

import java.util.List;

import com.training.model.Buyer;


public interface IBuyerService {
	
	 Buyer save(Buyer user);
	    List<Buyer> findAll();
	    void delete(int id);

	    Buyer findOne(String username);

	    Buyer findById(int id);

}
