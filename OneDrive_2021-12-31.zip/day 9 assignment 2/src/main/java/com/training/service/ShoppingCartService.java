package com.training.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.model.ShoppingCart;


@Service
public class ShoppingCartService implements IShoppingCart {

	@Autowired
	com.training.repository.ShoppingCartRepository repo;

	@Autowired(required = true)
	private com.training.model.ShoppingCart cart;

	@Override
	public com.training.model.ShoppingCart addToCart(com.training.model.ShoppingCart cart) {

		return repo.save(cart);
	}
	
	@Override
	public ShoppingCart updateCart(ShoppingCart cart) {
		Optional<ShoppingCart> p = repo.findById(cart.getProduct_id());
		if (p.isPresent()) {
			ShoppingCart indbproduct = p.get();
			System.out.println("Product indbproduct::" + indbproduct);
			indbproduct.setBuyer_id(cart.getBuyer_id());
			indbproduct.setId(cart.getProduct_id());
			indbproduct.setProduct_id(cart.getProduct_id());
			indbproduct.setQuantity(cart.getQuantity());
			repo.save(indbproduct);
			return indbproduct;
		} else {
			System.out.println("Product is not avaliable to update the Cart");
			return cart;
		}

	}
	
	@Override
	public List<Integer> showCart(int buyer_id) {
		return repo.showCart(buyer_id);

	}

	@Override
	public Integer deleteProductsFromCart(int pid) {
		 repo.deleteProductFromCart(pid);
		 return pid ;
	}

	

}
