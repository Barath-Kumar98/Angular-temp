import { Component } from '@angular/core';  
@Component({ 
    selector: 'app-root', 
    templateUrl: 'app.component.html' 
}) 
export class AppComponent { 
    Status: boolean = true; 
	ids: any[] =[1,2,3,4,5,6,7,8,9,0];
    myFunc() { 
	if(this.Status)
	{
        this.Status = false; 
	}
	else
	{
		this.Status = true;
	}
    } 
}