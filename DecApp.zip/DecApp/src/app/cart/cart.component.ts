import { Component, OnInit } from '@angular/core';
import { Cart } from '../model/cart';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartList: Cart[] =[];
  cartEmpty: boolean = true;
  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.getCartList();
    
  }

  getCartList() {
    this.productService.getCartList().subscribe((response: any)=>{
      this.cartList = response.filter((cart: Cart)=> !cart.purchaseStatus);
      console.log(this.cartList);
      if(this.cartList != null && this.cartList.length !=0){
        this.cartEmpty = false;
      }else{
        this.cartEmpty = true;
      }
    });
  }

  getTotalAmount(cart: Cart) {
    return (cart.product.productPrice * cart.purchaseQuantity);
  }

  checkout(cart: Cart) {
    
    
    //update cart

    // add to purchaseHistory
    this.productService.checkout(cart).subscribe((response: any)=>{
      alert("Order Placed Successfully");
    });

    this.getCartList();
  }
  

}
