import { Component, OnInit } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { Buyer } from '../model/buyer';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  // user: any = {firstName:'',
  //               lastName:'',
  //               age:0,
  //               gender:'',
  //               contactNumber:0,
  //               userID:'',
  //               password:'',
  //               userType:'',
  //               status:'',
  //               secretQuestion1:'',
  //               secretAnswer1:'',
  //               secretQuestion2:'',
  //               secretAnswer2:'',
  //               secretQuestion3:'',
  //               secretAnswer3:''};
  // //user: any;
  // registrationForm!: FormGroup;
  // userID!: FormControlName;
  // password!: FormControlName;
  // emailId!: FormControlName;

  userCreated!: boolean;
  userExists!: boolean;

  getUserID: string = "";
  getPassword: string = "";
  getEmailId: string = "";

  constructor(private authenticationService: AuthenticationService, private router: Router) { }

  ngOnInit() {
    this.userCreated = false;
    this.userExists = false;
    // this.registrationForm = new FormGroup({
    //   'firstName': new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(2)]),
    //   'lastName': new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(2)]),
    //   'age': new FormControl("", [Validators.required, Validators.maxLength(2), Validators.pattern("^[0-9]*$")]),
    //   'gender': new FormControl("", [Validators.required]),
    //   'contactNumber': new FormControl("", [Validators.required, Validators.maxLength(10), Validators.minLength(10), Validators.pattern("^[0-9]*$")]),
    //   'userID': new FormControl("", [Validators.required, Validators.maxLength(15), Validators.minLength(2)]),
    //   'password': new FormControl("", [Validators.required, Validators.maxLength(15), Validators.minLength(2)]),
    //   'userType': new FormControl("", [Validators.required]),
    //   'secretQuestion1': new FormControl("", [Validators.required]),
    //   'secretAnswer1': new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3)]),
    //   'secretQuestion2': new FormControl("", [Validators.required]),
    //   'secretAnswer2': new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3)]),
    //   'secretQuestion3': new FormControl("", [Validators.required]),
    //   'secretAnswer3': new FormControl("", [Validators.required, Validators.maxLength(50), Validators.minLength(3)])
    // });
  }

  sendValue(){
    // console.log(this.registrationForm.value);
    // this.user.firstName = this.registrationForm.value.firstName;
    // this.user.lastName = this.registrationForm.value.lastName;
    // this.user.age = this.registrationForm.value.age;
    // this.user.gender = this.registrationForm.value.gender;
    // this.user.contactNumber = this.registrationForm.value.contactNumber;
    // this.user.userID = this.registrationForm.value.userID;
    // this.user.password = this.registrationForm.value.password;
    // this.user.userType = this.registrationForm.value.userType;
    
    // if(this.user.userType == "U"){
    //   this.user.status = "A";
    // }else{
    //   this.user.status = "P";
    // }
    
    // this.user.secretQuestion1 = this.registrationForm.value.secretQuestion1;
    // this.user.secretAnswer1 = this.registrationForm.value.secretAnswer1;
    // this.user.secretQuestion2 = this.registrationForm.value.secretQuestion2;
    // this.user.secretAnswer2 = this.registrationForm.value.secretAnswer2;
    // this.user.secretQuestion3 = this.registrationForm.value.secretQuestion3;
    // this.user.secretAnswer3 = this.registrationForm.value.secretAnswer3;
    // console.log(this.user);
    let user: Buyer = {
      id: 0,
      username: this.getUserID,
      password: this.getPassword,
      emailId: this.getEmailId
    };
    this.authenticationService.register(user).subscribe((response: any)=>{
      this.userCreated = true;
    },
    (error: any)=>{
      this.userExists = true;
      this.userCreated = false;
    });
    
  }

  toLogin(){
    this.router.navigate(['login']);
  }

}
