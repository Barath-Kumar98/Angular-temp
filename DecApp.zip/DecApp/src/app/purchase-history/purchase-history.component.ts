import { Component, OnInit } from '@angular/core';
import { Cart } from '../model/cart';
import { PurchaseHistory } from '../model/purchase-history';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-purchase-history',
  templateUrl: './purchase-history.component.html',
  styleUrls: ['./purchase-history.component.css']
})
export class PurchaseHistoryComponent implements OnInit {

  cartList: Cart[] =[];
  purchaseList: PurchaseHistory[] = [];
  purchaseEmpty: boolean = true;
  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.getPurchaseList();
    
  }

  getPurchaseList() {
    this.productService.getPurchaseList().subscribe((response: any)=>{
      this.purchaseList = response.filter((cart: Cart)=> !cart.purchaseStatus);
      console.log(this.purchaseList);
      if(this.purchaseList != null && this.purchaseList.length !=0){
        this.purchaseEmpty = false;
      }else{
        this.purchaseEmpty = true;
      }
    });
  }

  getTotalAmount(cart: Cart) {
    return (cart.product.productPrice * cart.purchaseQuantity);
  }

  
  

}
