import { Component, Input, OnInit } from '@angular/core';
import { AbcdserviceService } from '../abcdservice.service';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit {
  @Input()
  value: number = 0;

  @Input()
  finalValue: number = 0;

  initialValue: number=0;
  constructor(private abcdService: AbcdserviceService) {
    console.log("Invoking service:" + this.abcdService.met());
   }

  ngOnInit(): void {
    this.initialValue = this.value;
  }

  increment() {
    this.value++;
    this.checkexceeded();
  }
  decrement() {
    this.value--;
    this.checkexceeded();
  }

  checkexceeded() {
    if(this.value >this.finalValue) {
      this.value = this.initialValue;
    }
  }
}
