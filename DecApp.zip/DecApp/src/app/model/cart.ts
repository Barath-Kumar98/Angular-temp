import { Buyer } from "./buyer";
import { Product } from "./product";

export interface Cart {
    id: number,
    product: Product,
    purchaseQuantity: number,
    buyer: Buyer,
    purchaseStatus: boolean
}
