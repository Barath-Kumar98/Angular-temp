export interface Buyer {
    id: number,
    username: string,
    password: string,
    emailId: string
}
