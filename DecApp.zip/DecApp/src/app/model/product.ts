export interface Product {
    id: number,
    productName: string,
    productModel: string,
    brandName: string,
    category: string,
    subCategory: string,
    productPrice: number,
    quantity: number,
    image: string,
    productSpecs: string,
    sellerId: number,
    status: string
}


export interface ProductDTO {
    product: Product,
    quantity: number,
    isSelected: boolean
}