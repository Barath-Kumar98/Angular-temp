import { Component } from '@angular/core';
import {FilterData} from './filterData';
@Component({
  selector: 'app-root',
	template: `
	<input type="text" [(ngModel)]="str">
	<ul>
	Matching elements:
	<li *ngFor="let point of (points | filterData: str : true)">
	{{point}}
	</li>

	Non Matching elements:
	<li *ngFor="let point of (points | filterData: str : false)">
	{{point}}
	</li>
	</ul>
	    `
})

export class AppComponent {
	str: string = "b";
	points: string[] = [
		 'aa',
		 'bb',
		 'cc',
		 'dd' 
	];
}