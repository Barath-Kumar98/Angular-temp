import { PfunctionPipe } from './pfunction.pipe';

describe('PfunctionPipe', () => {
  it('create an instance', () => {
    const pipe = new PfunctionPipe();
    expect(pipe).toBeTruthy();
  });
});
