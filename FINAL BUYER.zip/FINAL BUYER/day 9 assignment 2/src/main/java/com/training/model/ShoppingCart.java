package com.training.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Entity
@Table(name="Cart")
@Component
public class ShoppingCart {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name="quantity")
	private int quantity;
	
	@Column(name="product_id")
	private int product_id;
	
	@Column(name="buyerid")
	private int buyerid;
	
	private Date purchaseDate;
	
    @Column(columnDefinition = "boolean default false")
	private Boolean purchaseStatus ;

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public Boolean getPurchaseStatus() {
		return purchaseStatus;
	}

	public void setPurchaseStatus(Boolean purchaseStatus) {
		this.purchaseStatus = purchaseStatus;
	}
	
	public ShoppingCart(int id, int quantity, int product_id, int buyerid, Date purchaseDate, Boolean purchaseStatus) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.product_id = product_id;
		this.buyerid = buyerid;
		this.purchaseDate = purchaseDate;
		this.purchaseStatus = purchaseStatus;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public int getbuyerid() {
		return buyerid;
	}

	public void setbuyerid(int buyerid) {
		this.buyerid = buyerid;
	}

	@Override
	public String toString() {
		return "ShoppingCart [id=" + id + ", quantity=" + quantity + ", product_id=" + product_id + ", buyerid=" + buyerid + "]";
	}

	public ShoppingCart() {
	}
	

}
