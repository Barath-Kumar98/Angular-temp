package com.training;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.training.model.Buyer;

@Repository
public interface BuyerDao extends CrudRepository<Buyer, Integer> {

    Buyer findBybuyerName(String buyerName);
}
