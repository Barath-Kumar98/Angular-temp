//package com.training.controller;
//
//import java.net.URI;
//import java.net.URISyntaxException;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
//
//import com.training.model.Ticket;
//import com.training.service.TicketService;
//
//@RestController
//public class TicketController {
//
//	@Autowired
//	TicketService tService;
//	
//	@PostMapping("/bookTicket")
//	public void bookTicket(@RequestBody Ticket ticket) {
//		tService.saveTickets(ticket);
//	}
//	
//	@GetMapping("/getAllTickets")
//	public List<Ticket> getTickets() {
//		return tService.getTickets();
//	}
//
//	@DeleteMapping("/cancelTicket/{id}")
//	public int cancelTicket(@PathVariable("id") int id) {
//		tService.cancelTicket(id);
//		return id;
//		
//	}
//
//	@GetMapping("/fromplace/{fromPlace}/{toPlace}")
//	//getConf(@PathVariable("app") String app, @PathVariable("fnm") String fnm) 
//	public List<Ticket> fetchTicketByFromAndToPlace(@PathVariable("fromPlace") String fromPlace, @PathVariable("toPlace") String toPlace) {
//		return tService.findByFromPlaceAndToPlace(fromPlace, toPlace);
//		
//	}
//	
//	@GetMapping("JpqaFromPlaceToPlace/{fromPlace}/{toPlace}")
//	public List<Ticket> fetchTicketUsingJpqa(@PathVariable("fromPlace") String fromPlace, @PathVariable("toPlace") String toPlace) {
//		return tService.findTicketByFromPlaceAndToPlaceUsingJPQA(fromPlace, toPlace);
//	}
//	
//	
//	@GetMapping("nativeFromPlaceToPlace/{fromPlace}/{toPlace}")
//	public List<Ticket> fetchTicketUsingNative(@PathVariable("fromPlace") String fromPlace, @PathVariable("toPlace") String toPlace) {
//		return tService.findTicketUsingNativeQuery(fromPlace, toPlace);
//	}
//	
//	@GetMapping("/getproductsforseller")
//	public String getAllProducts() {
//
//		RestTemplate restTemplate = new RestTemplate();
//
//		final String baseUrl = "http://localhost:8989/mentorportal/sellerService/sellerTech/getSellerProduct";
//		URI uri = null;
//		try {
//			uri = new URI(baseUrl);
//		} catch (URISyntaxException e) {
//			e.printStackTrace();
//		}
//
//		ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
//
//		// Verify request succeed
//		System.out.println("Status code: " + result.getStatusCodeValue());
//		System.out.println("result: " + result.getBody());
//
//		return "Status code: " + result.getStatusCodeValue() + "<br>result: " + result.getBody();
//	}
//	
//}
