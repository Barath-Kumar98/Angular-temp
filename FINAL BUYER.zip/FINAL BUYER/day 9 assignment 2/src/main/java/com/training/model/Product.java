package com.training.model;

import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.catalina.startup.Catalina;

@Entity
@Table(name = "Product")
public class Product implements Comparator<Product> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pid;
	private String productname;
	private String status;
	private String productModel;
	private String brandName;// make
	private String category;
	private String subCategory;
	private double productPrice;
	private long quantity;
	private String image;
	private String productSpecs;
	private int sellerId;


	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

    public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getProductSpecs() {
		return productSpecs;
	}

	public void setProductSpecs(String productSpecs) {
		this.productSpecs = productSpecs;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public Product(String productName, String productModel, String brandName, String category, String subCategory,
            double productPrice, long quantity, String image, String productSpecs, int sellerId, String status) {
        super();
        this.productname = productName;
        this.productModel = productModel;
        this.brandName = brandName;
        this.category = category;
        this.subCategory = subCategory;
        this.productPrice = productPrice;
        this.quantity = quantity;
        this.image = image;
        this.productSpecs = productSpecs;
        this.sellerId = sellerId;
        this.status = status;
    }

	public Product() {
		super();
	}

	@Override
	public String toString() {
		return "\n Product [pid=" + pid + ", name=" + productname + ", price=" + productPrice + ", status=" + status + "]";
	}

	@Override
	public int compare(Product arg0, Product arg1) {
		return (int) (arg0.productPrice - arg1.productPrice);
	}

}
